'use strict'

var module = angular.module('demo.controllers', []);
module.controller("EmployeeController", [ "$scope", "Employee",
		function($scope, Employee) {

			$scope.employeeDtoArray = [];
			$scope.searchAge = 0;
	
			var employeeDto = {
				id : null,
				name : null,
				lastname : null,
				dob : null,
				sex : null,
				passport : null,
				city : null,
				martialstatus : null,
				skills : null
			};
			
			$scope.employeeDtoArray.push(employeeDto);
			
			 $scope.addRow = function() {
			      var employeeDto = {
			    		  	id : null,
							name : null,
							lastname : null,
							dob : null,
							sex : null,
							passport : null,
							city : null,
							martialstatus : null,
							skills : null
			      };
			      $scope.employeeDtoArray.push(employeeDto);
			 }
			
			 $scope.cancel = function() {
				 $scope.employeeDtoArray.length = 0;
			      var employeeDto = {
			    		  	id : null,
							name : null,
							lastname : null,
							dob : null,
							sex : null,
							passport : null,
							city : null,
							martialstatus : null,
							skills : null
			      };
			      $scope.employeeDtoArray.push(employeeDto);
			 }
			 
			Employee.getAllEmployees().then(function(value) {
				console.log(value.data);
			}, function(reason) {
				console.log("error occured");
			}, function(value) {
				console.log("no callback");
			});

			$scope.saveEmployees = function() {
				
				Employee.saveEmployees($scope.employeeDtoArray).then(function() {
					console.log("Employee saved");
					$scope.cancel();
					Employee.getAllEmployees().then(function(value) {
						$scope.allEmployees= value.data;
					}, function(reason) {
						console.log("error occured");
					}, function(value) {
						console.log("no callback");
					});

					$scope.employeeDto = {
							id : null,
							name : null,
							lastname : null,
							dob : null,
							sex : null,
							passport : null,
							city : null,
							martialstatus : null,
							skills : null
					};
				}, function(reason) {
					console.log("error occured");
				}, function(value) {
					console.log("no callback");
				});
			}
			
			 $scope.searchEmployeeDetails = function() {
				 Employee.searchEmployeeDetails($scope.searchAge).then(function(value) {
					 $scope.allEmployees= value.data;
					}, function(reason) {
						console.log("error occured");
					}, function(value) {
						console.log("no callback");
					});
			 }
			
			
		} ]);