'use strict'

var demoApp = angular.module('demo', [ 'ui.bootstrap', 'demo.controllers',
		'demo.services' ]);
demoApp.constant("CONSTANTS", {
	getAllEmployees : "/employee/getEmployeeDetails",
	createEmployee : "/employee/createEmployee",
	createEmployees : "/employee/createEmployees",
	updateEmployee : "/employee/updateEmployee",
	searchEmployeeDetails: "/employee/searchEmployeeDetails/"	
		
		
});