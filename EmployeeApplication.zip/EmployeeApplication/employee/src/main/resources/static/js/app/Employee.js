'use strict'

		angular.module('demo.services', []).factory('Employee', 
			["$http", "CONSTANTS", function($http, CONSTANTS) {
			var employee = {};
			
			employee.getAllEmployees = function() {
				return $http.get(CONSTANTS.getAllEmployees);
			}
			
			employee.searchEmployeeDetails = function(searchAge) {
				return $http.get(CONSTANTS.searchEmployeeDetails + searchAge);
			}
			
			employee.saveEmployee = function(employeeDto) {
				if(null != employeeDto && employeeDto.id != null){
					return $http.put(CONSTANTS.updateEmployee, employeeDto);
				}
				else if(null != employeeDto && employeeDto.id == null){
					return $http.post(CONSTANTS.createEmployee, employeeDto);
				}
			}

			employee.saveEmployees = function(employeeDtoArray) {
				return $http.post(CONSTANTS.createEmployees, employeeDtoArray);
			}
			return employee;
		}]);