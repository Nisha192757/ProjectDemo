/**
 * 
 */
package com.app.service;

import java.util.List;

import com.app.model.Employee;

/**
 * @author Nisha_Mittal
 *
 */
public interface EmployeeService {

	void createEmployees(List<Employee> employees);

	List<Employee> getEmployeeDetails();

	Employee saveEmployee(Employee employee);

	void deleteEmployee(Integer empId);

	List<Employee> searchEmployeeDetails(int age);

}
