/**
 * 
 */
package com.app.converter;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.app.dto.EmployeeDto;
import com.app.model.Employee;

/**
 * @author Nisha_Mittal
 *
 */
public class EmployeeConverter {
	
	public static Employee employeeDtoToEntity(EmployeeDto empDto) {
		LocalDate today = LocalDate.now();                          //Today's date	
		Date dob = empDto.getDob();
		Instant instant = Instant.ofEpochMilli(dob.getTime()); 
		LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()); 
		LocalDate birthday = localDateTime.toLocalDate();			//Birth date
					 
		Period p = Period.between(birthday, today);
		
		int age = p.getYears();
		
		Employee employee = new Employee(empDto.getId(), empDto.getName(), empDto.getLastname(), empDto.getSex(), empDto.getDob(), age, empDto.getCity(), empDto.getPassport(), empDto.getMartialstatus(), empDto.getSkills());
		return employee;
	}
	
	public static List<Employee> employeeDtoToEntity(List<EmployeeDto> empDtolist) {
		List<Employee> employees = new ArrayList<>();
		
		for(EmployeeDto empDto : empDtolist) {
			LocalDate today = LocalDate.now();                          //Today's date	
			Date dob = empDto.getDob();
			Instant instant = Instant.ofEpochMilli(dob.getTime()); 
			LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()); 
			LocalDate birthday = localDateTime.toLocalDate();			//Birth date
						 
			Period p = Period.between(birthday, today);
			
			int age = p.getYears();
		
			Employee employee = new Employee(empDto.getId(), empDto.getName(), empDto.getLastname(), empDto.getSex(), empDto.getDob(), age, empDto.getCity(), empDto.getPassport(), empDto.getMartialstatus(), empDto.getSkills());
			employees.add(employee);
		}
		return employees;
	}

}
