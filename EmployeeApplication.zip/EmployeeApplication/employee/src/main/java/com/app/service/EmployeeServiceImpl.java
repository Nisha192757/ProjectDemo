/**
 * 
 */
package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import com.app.model.Employee;
import com.app.repository.EmployeeRepository;

/**
 * @author Nisha_Mittal
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	/**
	 * create Employee
	 */
	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}


	/**
	 * create employees
	 */
	@Override
	public void createEmployees(List<Employee> employees) {
		 employeeRepository.saveAll(employees);
	}


	/**
	 * get all Employees
	 */
	@Override
	public List<Employee> getEmployeeDetails() {
		return employeeRepository.findAll();
	}

	/**
	 * delete Employee
	 */
	@Override
	public void deleteEmployee(Integer empId) {
		employeeRepository.deleteById(empId);		
	}

	/**
	 * fetch Employees based on age parameter
	 */
	@Override
	public List<Employee> searchEmployeeDetails(int age) {
		return employeeRepository.searchEmployeesFilterAge(age);
	}
	
	
	
}
