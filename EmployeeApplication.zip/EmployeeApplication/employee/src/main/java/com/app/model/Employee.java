/**
 * 
 */
package com.app.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author Nisha_Mittal
 *
 */
@Entity

public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5139569417882154318L;

	
	public Employee(Integer id, String name, String lastname, String sex, Date dob, int age, String city, String passport, String martialstatus, String skills) {
		super();
		this.id = id;
		this.name = name;
		this.lastname = lastname;
		this.sex = sex;
		this.dob = dob;
		this.age = age;
		this.city = city;
		this.passport = passport;
		this.martialstatus = martialstatus;
		this.skills = skills;
		
	}

	public Employee(Integer id, String name, String lastname, String sex, String city, String passport, String martialstatus, String skills) {
		super();
		this.id = id;
		this.name = name;
		this.lastname = lastname;
		this.sex = sex;
		this.city = city;
		this.passport = passport;
		this.martialstatus = martialstatus;
		this.skills = skills;
	}
	
	public Employee( String name, String sex, String city) {
		this.name = name;
		this.sex = sex;
		this.city = city;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private Integer id;

	@Column
	private String name;
	
	@Column
	private String lastname;

	@Column
	private String sex;

	@Column
	private Date dob;
	
	@Column
	private int age;
	
	@Column
	private String city;
	
	@Column
	private String passport;
	
	@Column
	private String martialstatus;
	
	@Column
	private String skills;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	public String getPassport() {
		return passport;
	}

	public void setPassport(String passport) {
		this.passport = passport;
	}

	
	public String getMartialstatus() {
		return martialstatus;
	}

	public void setMartialstatus(String martialstatus) {
		this.martialstatus = martialstatus;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}
	
	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


}
