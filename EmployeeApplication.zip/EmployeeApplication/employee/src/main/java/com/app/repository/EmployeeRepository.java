/**
 * 
 */
package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.model.Employee;

/**
 * @author Nisha_Mittal
 *
 */
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("FROM Employee AS e WHERE e.age > :age")
	List<Employee> searchEmployeesFilterAge(@Param("age") int age);

	// we can use Pageable request as well, to get only limited records based on page number
}
