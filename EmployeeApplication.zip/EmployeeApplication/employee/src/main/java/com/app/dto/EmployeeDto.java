/**
 * 
 */
package com.app.dto;

import java.util.Date;

import org.springframework.stereotype.Component;

/**
 * @author Nisha_Mittal
 *
 */
@Component
public class EmployeeDto {

	public EmployeeDto() {

	}

	public EmployeeDto(Integer id, String name, String lastname, String sex, Date dob, int age, String city, String passport, String martialstatus, String skills) {
		this.id = id;
		this.name = name;
		this.lastname = lastname;
		this.sex = sex;
		this.dob = dob;
		this.age = age;
		this.city = city;
		this.passport = passport;
		this.martialstatus = martialstatus;
		this.skills = skills;
	}


	public EmployeeDto(Integer id, String name, String lastname, String sex, String city, String passport, String martialstatus, String skills) {
		this.id = id;
		this.name = name;
		this.lastname = lastname;
		this.sex = sex;
		this.city = city;
		this.passport = passport;
		this.martialstatus = martialstatus;
		this.skills = skills;
	}
	
	private Integer id;

	private String name;
	
	private String lastname;

	private String sex;

	private Date dob;

	private int age;
	
	private String city;
	
	private String passport;
	
	private String martialstatus;
	
	private String skills;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPassport() {
		return passport;
	}

	public void setPassport(String passport) {
		this.passport = passport;
	}

	public String getMartialstatus() {
		return martialstatus;
	}

	public void setMartialstatus(String martialstatus) {
		this.martialstatus = martialstatus;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}
	
	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


}
