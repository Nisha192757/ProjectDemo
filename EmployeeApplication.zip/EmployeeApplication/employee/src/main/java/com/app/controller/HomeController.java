/**
 * 
 */
package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Nisha_Mittal
 *
 */

@Controller
public class HomeController {
	
	@RequestMapping("/employee")
	public String home() {
		return "index";
	}	

}


