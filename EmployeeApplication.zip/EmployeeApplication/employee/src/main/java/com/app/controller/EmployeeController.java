/**
 * 
 */
package com.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.converter.EmployeeConverter;
import com.app.dto.EmployeeDto;
import com.app.model.Employee;
import com.app.service.EmployeeService;

/**
 * @author Nisha_Mittal
 *
 */

@RequestMapping("/employee")
@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/detail")
	public ResponseEntity<Object> getTestDetails() {
		Employee emp = new Employee();
		emp.setName("Nick");
		emp.setSex("M");
		emp = employeeService.saveEmployee(emp);
		return ResponseEntity.ok(emp);
	}
	
	@GetMapping("/testing")
	public ResponseEntity<Object> testing() {
		
		return ResponseEntity.ok("test completed");
	}

	@GetMapping("/getEmployeeDetails")
	public ResponseEntity<Object> getEmployeeDetails() {
		List<Employee> allEmployees = employeeService.getEmployeeDetails();
		return ResponseEntity.ok(allEmployees);
	}

	@PostMapping("/createEmployee")
	public ResponseEntity<Object> createEmployee(@RequestBody EmployeeDto empDto) {
		Employee employee = EmployeeConverter.employeeDtoToEntity(empDto);
		try {
			employee = employeeService.saveEmployee(employee);

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erorr creating Employee");
		}

		return ResponseEntity.ok(employee);
	}

	@PutMapping("/updateEmployee")
	public ResponseEntity<Object> updateEmployee(@RequestBody EmployeeDto empDto) {
		Employee employee = EmployeeConverter.employeeDtoToEntity(empDto);
		try {
			employee = employeeService.saveEmployee(employee);

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erorr updating Employees");
		}

		return ResponseEntity.ok(employee);
	}

	@PostMapping("/createEmployees")
	public ResponseEntity<Object> createEmployees(@RequestBody EmployeeDto[] empDtoArray) {
		List<Employee> allEmployees = null;
		try {
			if(null!= empDtoArray && empDtoArray.length > 0) {
				List<EmployeeDto> empDtolist = new ArrayList<>(Arrays.asList(empDtoArray));
				allEmployees = EmployeeConverter.employeeDtoToEntity(empDtolist);
			}
			employeeService.createEmployees(allEmployees);
			allEmployees = employeeService.getEmployeeDetails();

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erorr creating Employees");
		}

		return ResponseEntity.ok(allEmployees);
	}

	@DeleteMapping("/deleteEmployee/{id}")
	public ResponseEntity<Object> deleteEmployee(@PathVariable Integer empId) {
		try {
			employeeService.deleteEmployee(empId);

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erorr deleting Employees");
		}

		return ResponseEntity.ok("Employee has been deleted Successfully");
	}

	@GetMapping("/searchEmployeeDetails/{age}")
	public ResponseEntity<Object> searchEmployeeDetails(@PathVariable("age") int age) {
		List<Employee> allEmployees = null;
		try {
			allEmployees = employeeService.searchEmployeeDetails(age);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erorr getting Employee details");
		}
		return ResponseEntity.ok(allEmployees);
	}
}
