/**
 * 
 */
package Contant;

/**
 * @author Nisha_Mittal
 *
 */
public class Constants {
	
	 final String CREATE_EMPLOYEE = "/createEmployee";
	 final String CREATE_EMPLOYEES = "/createEmployees";
	 final String GET_EMPLOYEE_DETAILS = "/getEmployeeDetails";
	 final String EDIT_EMPLOYEES = "/editEmployees";	

}
