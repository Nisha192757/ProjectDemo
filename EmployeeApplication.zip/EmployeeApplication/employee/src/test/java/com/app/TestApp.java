/**
 * 
 */
package com.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.app.controller.EmployeeController;

/**
 * @author Nisha_Mittal
 *
 */



public class TestApp extends EmployeeApplicationTests  {
	
	@Autowired
	private EmployeeController empCtrl;
	

	   @Test
	    public void testEmployeeController() {
	        ResponseEntity<Object> result = empCtrl.testing();
	        assertEquals(result.getBody(), "test completed");
	        assertEquals(result.getStatusCode(), 200);
	    }

	   @Test
	    public void testGetEmployeeDetails() {
	        ResponseEntity<Object> result = empCtrl.getEmployeeDetails();
	        assertNotNull("object is Null", result.getBody());
	        assertNull("object is not Null", result.getBody());
	        assertEquals(result.getStatusCode(), 200);
	    }
	   
}
